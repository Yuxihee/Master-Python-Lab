from flask import Flask, render_template, request
import sqlite3 as sql

app = Flask(__name__)

@app.route('/')
def home():
    import sqlite3
    conn = sqlite3.connect('studentdb.db')
    try:
        print ("Opened database successfully");
        conn.execute('CREATE TABLE students (name TEXT, major TEXT, university TEXT, satisfied TEXT , suggestion TEXT)')
        print ("Table created successfully");
    except:
        print("erro")
    return render_template("home.html")
    conn.close()


@app.route('/enternew')
def new_student():
   return render_template('student.html')

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
   if request.method == 'POST':
      try:
         name = request.form['name']
         major = request.form['major']
         university = request.form['university']
         satisfied = request.form['satisfied']
         suggestion = request.form['suggestion']
         with sql.connect("studentdb.db") as con:
            cur = con.cursor()            
            cur.execute("INSERT INTO students (name,major,university,satisfied,suggestion)  VALUES (?,?,?,?,?)",(name,major,university,satisfied,suggestion) )
            con.commit()
            msg = "Record successfully added"
      except:
         con.rollback()
         msg = "error in insert operation"
      
      finally:
         return render_template("result.html",msg = msg)
         con.close()

@app.route('/list')
def list():
   con = sql.connect("studentdb.db")
   con.row_factory = sql.Row
   cur = con.cursor()
   cur.execute("select * from students")   
   rows = cur.fetchall();
   return render_template("list.html",rows = rows)

if __name__ == '__main__':
   app.run(debug = True)